const express = require('express');
const router = express.Router();
const {createEvent, readEvent, readAll, updateEvent, deleteEvent} = require('../controllers/eventManager');

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const YourModelSchema = new Schema({
    title: String
});
const YourModel = mongoose.model('YourModel', YourModelSchema);

// CRUD operations for events
router.post('/', createEvent);
router.get('/:id', readEvent);
router.get('/', readAll);
router.patch('/:id', updateEvent);
router.delete('/:id', deleteEvent);

module.exports = router;