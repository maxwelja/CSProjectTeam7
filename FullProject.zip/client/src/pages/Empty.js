import GetBtn from '../components/GetBtn'

const Empty = () => {

  return (
    <div className="empty">
      <GetBtn />
    </div>
  )
}

export default Empty;