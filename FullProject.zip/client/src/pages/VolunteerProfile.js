import '../styles/VolunteerProfile.css';
import { Button, Container, Col, Row, Image} from 'react-bootstrap';
import NavBar from '../components/NavBar';
import ModalBtn from '../components/Modal';

function didIt() {
  alert("You did it!");
}
function didnt() {
  alert("You didn't!");
}

function VolunteerProfile() {
  return (
    <>
    <div id="main">
        <Col id="sidebar"></Col>
          <Container id='mainContainer'>
            <Col id="mainCol">
              <NavBar />

              <Row id="row2">
                <Col id="profile">
                  <Image src="images/profilePic.png" />
                </Col>
                <Col>
                  < Container id="container2">
                      <Container id="infoContainer">
                          <Row>Name: Jacob Maxwell</Row>
                          <Row>Email: jam190009@utdallas.edu</Row>
                          <Row>Phone: (123)456-7890</Row>
                          <Row>Summary:<br />Hello, my name is Jacob and I volunteer! and stuff and things and yippeeeeeeee</Row>
                      </Container>
                  </Container>
                </Col>
              </Row>

              <div className='box' id='box1'>
                <Col id='bot-left'>
                <Container id="container3">
                  <div className='box' id='box2'>
                      <Col id='kRating'>
                      Karma<br />
                      Rating
                      </Col>
                      <Container id="karma">
                        0
                      </Container>
                  </div>
                  <Button onClick={didIt} variant='primary'>Events RSVP'd</Button>
                  <Button onClick={didnt} variant='primary'>Events Attended</Button>
                </Container>
                </Col>

                <Col id="bot-right">
                  <Container id="container4">
                  <div className='box' id='box3'>
                      <Col id="vhours">
                      Volunteer<br/>Hours
                      </Col>
                      <Container id="hours">
                        0
                      </Container>
                  </div>
                  <div className='box' id="box4">
                    <Col id="attended">
                      Events<br/>Attended
                    </Col>
                    <Container id="events">
                      0
                    </Container>
                  </div>
                  </Container>

                  <Container id="container5">
                  <div className='box' id='box4'>
                      <ModalBtn color="black"/>
                  </div>
                  </Container>
                </Col>
              </div>
            </Col>
          </Container>
        <Col id="sidebar"></Col>
      </div>
    </>
  );
}

export default VolunteerProfile;