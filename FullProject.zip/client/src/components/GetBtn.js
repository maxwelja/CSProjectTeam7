import React, { useState } from 'react';
import {Button} from 'react-bootstrap';
import axios from 'axios';

const GetBtn = ({name, collection}) => {
    const [data, setData] = useState(null);
    
    const fetchData = async () => {
        try {
            const response = await axios.get(`/api/${collection}`);
            setData(response.data);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    return (
        <div>
            <Button
                name={name}
                collection={collection}
                onClick={fetchData}
            >
                {name}
            </Button>
            {data && <div>{/* Display fetched data here */}</div>}
        </div>
    );
};

export default GetBtn;