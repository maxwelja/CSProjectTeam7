import { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function ModalBtn() {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [events, setEvents] = useState(null);

  useEffect(() => {
    const getEvents = async () => {
      const response = await fetch('/api/events');
      const json = await response.json();

      if (response.ok) {
        setEvents(json);
      }

      getEvents();
    };
  }, []);

  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Events Near Me
      </Button>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Events</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {events && events.map((event) => (
            <p key={event._id}>Hello{event.title}</p>
          )
        )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ModalBtn;