const mongoose = require('mongoose');

// Schema for users of app
const UserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    date: {
        type: Date,
        default: Date.now,
    },
});

const user = mongoose.model('users', UserSchema);
// use schema to build a model for the mongodb collection 
module.exports = user;