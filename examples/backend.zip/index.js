require('dotenv').config();
const routes = require('./routing');
const mongoose = require('mongoose');
console.log('trying...');

// For backend setup
// imports
const express = require('express');
const cors = require("cors");

// build express app
const app = express();

// tell express to collect data in .json format
app.use(express.json());

// allows cross origin response sharing (communication between the different ports for frontend and backend)
app.use(cors());

// tells express where the api endpoints are
app.use('/test/', routes);

mongoose.connect(process.env.MONGO_URI)
    .then (() => {
        // listen for requests on given port
        app.listen(process.env.PORT, () => {
            console.log('Connected!');
        });
    })
    .catch((error) => {
        console.log(error);
    });